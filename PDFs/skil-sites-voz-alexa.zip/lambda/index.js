const Alexa = require('ask-sdk-core');

const SITE_MAP = {
    "concentrador": "https://sites.google.com/view/concentrador/p%C3%A1gina-inicial",
    "gerenciador de medicamentos": "https://psicspsix.github.io/Gerenciador-de-Medicamentos/",
    "gerenciador de tarefas": "https://psicspsix.github.io/Tarefas-JPV/",
    "gerenciador de pagamentos e projetos": "https://psicspsix.github.io/Pagamentos-e-Projetos/",
    "projetos complexos": "https://psicspsix.github.io/Projetos-Complexos/",
    "projetos compartilhados": "https://psicspsix.github.io/Projetos-Complexos-Compartilhados/",
    "frases e cita��es": "https://psicspsix.github.io/Frases-e-Citacoes/",
    "prompts para ias": "https://psicspsix.github.io/Prompts-IAs/",
    "visualizador de contos": "https://psicspsix.github.io/LeitorPDFparaSmartTVs/",
    "leitor de pdf em voz alta": "https://psicspsix.github.io/LeituraPDFemVoz/",
    "visualizador de processos": "https://psicspsix.github.io/LerPDFemLinksFixos/",
    "jogo de forca": "https://psicspsix.github.io/JogoLorca",
    "pesquisa de playlists": "https://psicspsix.github.io/PesquisaPlaylists/",
    "programa coringa": "https://psicspsix.github.io/PROGRAMA-CORINGA-INDEX-TEMPORARIOS/",
    "p6": "https://posicionamentospolemicos.vercel.app/",
    "favoritos dos notes": "https://sites.google.com/view/favoritos-dos-notes/p%C3%A1gina-inicial?pli=1&authuser=2",
    "favoritos do btv": "https://sites.google.com/view/favoritos-do-btv/p%C3%A1gina-inicial",
    "mang�s manhuas e manhwas": "https://sites.google.com/d/1XilqLJJPVK8SnZbmQ1x6hC7E3Wr74QEo/p/18_scaoaLjnvYTVFfhQBcw1dIDJtJPtCq/edit",
    "sites do google": "https://sites.google.com/new?hl=pt-PT",
    "graphite writer": "https://app.graphitewriter.com/"
};

const OpenSiteIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === "IntentRequest"
            && Alexa.getIntentName(handlerInput.requestEnvelope) === "OpenSiteIntent";
    },
    handle(handlerInput) {
        const siteSlot = handlerInput.requestEnvelope.request.intent.slots.site.value;

        if (!siteSlot) {
            return handlerInput.responseBuilder
                .speak("N�o entendi o nome do site. Diga: abrir site e o nome.")
                .getResponse();
        }

        const normalized = siteSlot.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
        const url = SITE_MAP[normalized];

        if (!url) {
            return handlerInput.responseBuilder
                .speak("N�o encontrei esse site. Diga: abrir site e o nome.")
                .getResponse();
        }

        return handlerInput.responseBuilder
            .speak("Abrindo site...")
            .addDirective({
                type: "Alexa.Presentation.APL.ExecuteCommands",
                token: "launch",
                commands: [
                    {
                        type: "LaunchURL",
                        source: url
                    }
                ]
            })
            .getResponse();
    }
};

const LaunchRequestHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === "LaunchRequest";
    },
    handle(handlerInput) {
        return handlerInput.responseBuilder
            .speak("Diga abrir site e o nome do site.")
            .getResponse();
    }
};

exports.handler = Alexa.SkillBuilders.custom()
    .addRequestHandlers(
        LaunchRequestHandler,
        OpenSiteIntentHandler
    )
    .lambda();
